﻿$Slab = {
    selectedloadSlabDetail: 0,
    id: 0,
    loadInitial: function () {
        
       
        $companyCom.loadSlabDetail({ id: "ddSlab" });
    }

}